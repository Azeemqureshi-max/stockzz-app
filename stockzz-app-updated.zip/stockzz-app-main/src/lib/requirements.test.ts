import { describe, expect, it } from 'vitest'

import { listStocks } from './market'
import { filterStocksByRequirements, matchedRequirementLabels, type ResearchRequirements } from './requirements'

const base: ResearchRequirements = {
  market: 'India',
  exchange: 'Any',
  sector: 'Any',
  capSize: 'Any',
  risk: 'Balanced',
  maxSharePrice: '',
  minRevenueGrowth: '',
  profitableOnly: false,
  maxDebtToEquity: '',
  positiveCashFlow: false,
  maxPe: '',
  horizon: 'Any',
  notes: '',
}

describe('research requirement filters', () => {
  it('limits results to the selected market', () => {
    const results = filterStocksByRequirements(listStocks(), { ...base, market: 'India' })
    expect(results.length).toBeGreaterThan(0)
    expect(results.every((stock) => ['NSE', 'BSE'].includes(stock.profile.exchange))).toBe(true)
  })

  it('applies multiple financial criteria together', () => {
    const results = filterStocksByRequirements(listStocks(), {
      ...base,
      market: 'US',
      sector: 'Technology',
      profitableOnly: true,
      positiveCashFlow: true,
      maxDebtToEquity: '0.5',
    })
    expect(results.map((stock) => stock.profile.symbol)).toEqual(expect.arrayContaining(['MSFT', 'NVDA']))
    expect(results.every((stock) => stock.fundamentals.netIncome > 0)).toBe(true)
    expect(results.every((stock) => stock.fundamentals.operatingCashFlow > 0)).toBe(true)
    expect(results.every((stock) => stock.fundamentals.debtToEquity <= 0.5)).toBe(true)
  })

  it('can narrow an Indian market search to one exchange and a share-price ceiling', () => {
    const results = filterStocksByRequirements(listStocks(), {
      ...base,
      market: 'India',
      exchange: 'NSE',
      maxSharePrice: '2000',
      risk: 'Higher',
    })
    expect(results.length).toBeGreaterThan(0)
    expect(results.every((stock) => stock.profile.exchange === 'NSE')).toBe(true)
    expect(results.every((stock) => stock.quote.price <= 2000)).toBe(true)
  })

  it('does not compare share prices across currencies when all markets are selected', () => {
    const results = filterStocksByRequirements(listStocks(), {
      ...base,
      market: 'All',
      maxSharePrice: '1',
      risk: 'Higher',
    })
    expect(results).toHaveLength(listStocks().length)
  })

  it('returns an empty list instead of inventing matches', () => {
    const results = filterStocksByRequirements(listStocks(), {
      ...base,
      market: 'India',
  exchange: 'Any',
      sector: 'Healthcare',
    })
    expect(results).toEqual([])
  })

  it('describes criteria that a returned company actually satisfies', () => {
    const stock = listStocks().find((item) => item.profile.symbol === 'INFY')
    expect(stock).toBeDefined()
    const labels = matchedRequirementLabels(stock!, {
      ...base,
      market: 'India',
  exchange: 'Any',
      sector: 'Technology',
      profitableOnly: true,
      positiveCashFlow: true,
    })
    expect(labels).toContain('Indian market')
    expect(labels).toContain('Technology')
    expect(labels).toContain('Positive net income')
    expect(labels).toContain('Positive operating cash flow')
  })
})
