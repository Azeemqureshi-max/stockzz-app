import type { Exchange, StockRecord } from './types'

export type RequirementMarket = 'All' | 'India' | 'US'
export type RequirementRisk = 'Lower' | 'Balanced' | 'Higher'
export type CompanySize = 'Any' | 'Large Cap' | 'Mid Cap' | 'Small Cap'

export interface ResearchRequirements {
  market: RequirementMarket
  exchange: 'Any' | Exchange
  sector: string
  capSize: CompanySize
  risk: RequirementRisk
  /** Maximum quoted price per share, in the selected market's currency. */
  maxSharePrice: string
  minRevenueGrowth: string
  profitableOnly: boolean
  maxDebtToEquity: string
  positiveCashFlow: boolean
  maxPe: string
  /** Context only: the current dataset has no evidence to evaluate a horizon. */
  horizon: 'Any' | 'Short term' | 'Medium term' | 'Long term'
  /** Context only: free text is not interpreted as a filter. */
  notes: string
}

function numericValue(value: string): number | undefined {
  if (!value.trim()) return undefined
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : undefined
}

function matchesRisk(stock: StockRecord, risk: RequirementRisk) {
  if (risk === 'Higher') return true
  const steady = stock.technicals.trend !== 'bearish' && stock.fundamentals.debtToEquity <= 1
  if (risk === 'Lower') {
    return steady && stock.fundamentals.netIncomeGrowthPct >= 0 && stock.fundamentals.revenueGrowthPct < 60
  }
  return steady || stock.fundamentals.netIncomeGrowthPct > 10
}

/** Deterministic filtering over the currently available provider records only. */
export function filterStocksByRequirements(stocks: StockRecord[], requirements: ResearchRequirements) {
  const maxPrice = requirements.market === 'All' ? undefined : numericValue(requirements.maxSharePrice)
  const minRevenueGrowth = numericValue(requirements.minRevenueGrowth)
  const maxDebt = numericValue(requirements.maxDebtToEquity)
  const maxPe = numericValue(requirements.maxPe)

  return stocks.filter((stock) => {
    const isIndia = stock.profile.exchange === 'NSE' || stock.profile.exchange === 'BSE'
    if (requirements.market === 'India' && !isIndia) return false
    if (requirements.market === 'US' && isIndia) return false
    if (requirements.exchange !== 'Any' && stock.profile.exchange !== requirements.exchange) return false
    if (requirements.sector !== 'Any' && stock.profile.sector !== requirements.sector) return false
    if (requirements.capSize !== 'Any' && stock.profile.capSize !== requirements.capSize) return false
    if (maxPrice !== undefined && stock.quote.price > maxPrice) return false
    if (minRevenueGrowth !== undefined && stock.fundamentals.revenueGrowthPct < minRevenueGrowth) return false
    if (requirements.profitableOnly && stock.fundamentals.netIncome <= 0) return false
    if (maxDebt !== undefined && stock.fundamentals.debtToEquity > maxDebt) return false
    if (requirements.positiveCashFlow && stock.fundamentals.operatingCashFlow <= 0) return false
    if (maxPe !== undefined && stock.fundamentals.pe > maxPe) return false
    return matchesRisk(stock, requirements.risk)
  })
}

/** Plain-language filters that actually constrained the returned record. */
export function matchedRequirementLabels(stock: StockRecord, requirements: ResearchRequirements) {
  const labels: string[] = []
  if (requirements.market !== 'All') labels.push(requirements.market === 'India' ? 'Indian market' : 'US market')
  if (requirements.exchange !== 'Any') labels.push(requirements.exchange)
  if (requirements.sector !== 'Any') labels.push(requirements.sector)
  if (requirements.capSize !== 'Any') labels.push(requirements.capSize)
  const maxPrice = requirements.market === 'All' ? undefined : numericValue(requirements.maxSharePrice)
  const minRevenueGrowth = numericValue(requirements.minRevenueGrowth)
  const maxDebt = numericValue(requirements.maxDebtToEquity)
  const maxPe = numericValue(requirements.maxPe)
  if (maxPrice !== undefined && stock.quote.price <= maxPrice) labels.push(`Price ≤ ${maxPrice}`)
  if (minRevenueGrowth !== undefined && stock.fundamentals.revenueGrowthPct >= minRevenueGrowth) labels.push(`Revenue growth ≥ ${minRevenueGrowth}%`)
  if (requirements.profitableOnly && stock.fundamentals.netIncome > 0) labels.push('Positive net income')
  if (maxDebt !== undefined && stock.fundamentals.debtToEquity <= maxDebt) labels.push(`Debt / equity ≤ ${maxDebt}`)
  if (requirements.positiveCashFlow && stock.fundamentals.operatingCashFlow > 0) labels.push('Positive operating cash flow')
  if (maxPe !== undefined && stock.fundamentals.pe <= maxPe) labels.push(`P/E ≤ ${maxPe}`)
  if (requirements.risk !== 'Higher') labels.push(`${requirements.risk.toLowerCase()} risk indicators`)
  return labels.length ? labels : ['No additional filters']
}
