import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowRight, CircleAlert, CircleCheck, Megaphone, Search, SlidersHorizontal, Star } from 'lucide-react'
import { useMemo, useState } from 'react'

import { Button } from '@/components/ui/button'
import { Change, CompanyMark, DemoBadge, Disclaimer, SourceLine } from '@/components/stockzz/common'
import { DEMO_MARKET_MOOD } from '@/data/demo-fixtures'
import { money } from '@/lib/format'
import { filterStocksByRequirements, matchedRequirementLabels, type ResearchRequirements } from '@/lib/requirements'
import { listStocks } from '@/lib/market'
import { valueHolding } from '@/lib/portfolio'
import type { Currency, StockRecord } from '@/lib/types'
import { cn } from '@/lib/utils'
import { useWorkspace } from '@/lib/workspace'

export const Route = createFileRoute('/app/suggestions')({
  head: () => ({ meta: [{ title: 'Suggestions · Stockzz' }] }),
  component: Suggestions,
})

type Market = 'All' | 'India' | 'US'
type Risk = 'Lower' | 'Balanced' | 'Higher'
const SECTORS = ['Technology', 'Financials', 'Energy', 'Automobile', 'Healthcare']

function greeting() {
  const h = new Date().getHours()
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'
}

function fitsRisk(s: StockRecord, risk: Risk) {
  if (risk === 'Higher') return true
  const steady = s.technicals.trend !== 'bearish' && s.fundamentals.debtToEquity <= 1
  if (risk === 'Lower') return steady && s.fundamentals.netIncomeGrowthPct >= 0 && s.fundamentals.revenueGrowthPct < 60
  return steady || s.fundamentals.netIncomeGrowthPct > 10
}

function Suggestions() {
  const { user, holdings, saved } = useWorkspace()
  const [mode, setMode] = useState<'explore' | 'requirements'>('explore')
  const [market, setMarket] = useState<Market>('All')
  const [risk, setRisk] = useState<Risk>('Balanced')
  const [sectors, setSectors] = useState<string[]>([])
  const [showAll, setShowAll] = useState(false)
  const [showPrefs, setShowPrefs] = useState(false)
  const [hello] = useState(greeting)
  const [requirements, setRequirements] = useState<ResearchRequirements>({
    market: 'India',
    exchange: 'Any',
    sector: 'Any',
    capSize: 'Any',
    risk: 'Balanced',
    maxSharePrice: '',
    minRevenueGrowth: '',
    profitableOnly: false,
    maxDebtToEquity: '',
    positiveCashFlow: false,
    maxPe: '',
    horizon: 'Any',
    notes: '',
  })
  const [hasSearched, setHasSearched] = useState(false)

  const results = useMemo(
    () =>
      listStocks().filter((s) => {
        const india = s.profile.exchange === 'NSE' || s.profile.exchange === 'BSE'
        if (market === 'India' && !india) return false
        if (market === 'US' && india) return false
        if (sectors.length && !sectors.includes(s.profile.sector)) return false
        return fitsRisk(s, risk)
      }),
    [market, risk, sectors],
  )
  const visible = showAll ? results : results.slice(0, 3)
  const requirementResults = useMemo(
    () => filterStocksByRequirements(listStocks(), requirements),
    [requirements],
  )

  // Totals per currency — never mix ₹ and $ into one number.
  const totals = holdings.reduce<Partial<Record<Currency, number>>>((acc, h) => {
    const v = valueHolding(h)
    acc[h.currency] = (acc[h.currency] ?? 0) + (v.value ?? v.invested)
    return acc
  }, {})

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
          {hello}, {user?.name.split(' ')[0]}! <span aria-hidden>👋</span>
        </h1>
        <p className="mt-1 text-muted-foreground">Explore company research or narrow the demo list using your own criteria.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Markets" demo>
          <p className="text-xl font-bold text-positive">{DEMO_MARKET_MOOD.label}</p>
          <p className="text-sm text-muted-foreground">
            {DEMO_MARKET_MOOD.index}{' '}
            <span className="font-medium text-positive">+{DEMO_MARKET_MOOD.changePct}%</span>
          </p>
        </StatCard>
        <StatCard label="Your portfolio" demo={holdings.length > 0}>
          {holdings.length === 0 ? (
            <>
              <p className="text-xl font-bold">No investments yet</p>
              <Link to="/app/portfolio" className="text-sm font-medium text-primary hover:underline">Add one you own →</Link>
            </>
          ) : (
            <>
              <p className="text-xl font-bold tabular-nums">
                {(Object.entries(totals) as [Currency, number][]).map(([c, v]) => money(v, c, 0)).join(' · ')}
              </p>
              <p className="text-sm text-muted-foreground">
                {holdings.length} holding{holdings.length > 1 ? 's' : ''} ·{' '}
                <Link to="/app/portfolio" className="font-medium text-primary hover:underline">View</Link>
              </p>
            </>
          )}
        </StatCard>
        <StatCard label="Saved stocks">
          <p className="text-xl font-bold">{saved.length}</p>
          <p className="text-sm text-muted-foreground">
            Stocks you follow · <Link to="/app/saved" className="font-medium text-primary hover:underline">View</Link>
          </p>
        </StatCard>
      </div>

      <section aria-labelledby="sugg-h" className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 id="sugg-h" className="text-lg font-semibold">Stock research</h2>
            <p className="text-sm text-muted-foreground">Choose how you want to explore the available companies.</p>
          </div>
          <div className="inline-flex rounded-xl border bg-muted p-1" role="group" aria-label="Suggestions mode">
            <button
              type="button"
              onClick={() => setMode('explore')}
              aria-pressed={mode === 'explore'}
              className={cn('rounded-lg px-3 py-2 text-sm font-medium transition-colors', mode === 'explore' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground')}
            >
              Explore Stocks
            </button>
            <button
              type="button"
              onClick={() => setMode('requirements')}
              aria-pressed={mode === 'requirements'}
              className={cn('rounded-lg px-3 py-2 text-sm font-medium transition-colors', mode === 'requirements' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground')}
            >
              My Requirements
            </button>
          </div>
        </div>

        {mode === 'explore' ? (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="font-semibold">Top stock ideas to research</h3>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setShowPrefs((v) => !v)} aria-expanded={showPrefs}>
                  <SlidersHorizontal /> Your preferences
                </Button>
                {results.length > 3 && (
                  <Button variant="ghost" size="sm" className="text-primary" onClick={() => setShowAll((v) => !v)}>
                    {showAll ? 'Show fewer' : `View all (${results.length})`}
                  </Button>
                )}
              </div>
            </div>

            {showPrefs && (
              <div className="grid gap-5 rounded-2xl border bg-card p-5 sm:grid-cols-3">
                <PrefGroup label="Market">
                  {(['All', 'India', 'US'] as Market[]).map((m) => (
                    <Chip key={m} active={market === m} onClick={() => setMarket(m)}>{m}</Chip>
                  ))}
                </PrefGroup>
                <PrefGroup label="Comfort with ups and downs">
                  {(['Lower', 'Balanced', 'Higher'] as Risk[]).map((r) => (
                    <Chip key={r} active={risk === r} onClick={() => setRisk(r)}>{r}</Chip>
                  ))}
                </PrefGroup>
                <PrefGroup label="Sectors you’re curious about">
                  {SECTORS.map((s) => (
                    <Chip
                      key={s}
                      active={sectors.includes(s)}
                      onClick={() => setSectors((cur) => (cur.includes(s) ? cur.filter((x) => x !== s) : [...cur, s]))}
                    >
                      {s}
                    </Chip>
                  ))}
                </PrefGroup>
              </div>
            )}

            {visible.length === 0 ? (
              <div className="rounded-2xl border border-dashed bg-card p-10 text-center">
                <p className="font-semibold">No ideas match these preferences yet</p>
                <p className="mt-1 text-sm text-muted-foreground">Try choosing more sectors or a different market.</p>
                <Button className="mt-4" variant="outline" onClick={() => { setSectors([]); setMarket('All'); setRisk('Balanced') }}>
                  Reset preferences
                </Button>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {visible.map((s) => (
                  <SuggestionCard key={s.profile.symbol} stock={s} />
                ))}
              </div>
            )}
          </>
        ) : (
          <RequirementsPanel
            requirements={requirements}
            setRequirements={setRequirements}
            results={requirementResults}
            hasSearched={hasSearched}
            onSearch={() => setHasSearched(true)}
          />
        )}
      </section>

      <Disclaimer />
    </div>
  )
}

function RequirementsPanel({
  requirements,
  setRequirements,
  results,
  hasSearched,
  onSearch,
}: {
  requirements: ResearchRequirements
  setRequirements: React.Dispatch<React.SetStateAction<ResearchRequirements>>
  results: StockRecord[]
  hasSearched: boolean
  onSearch: () => void
}) {
  const update = <K extends keyof ResearchRequirements>(key: K, value: ResearchRequirements[K]) =>
    setRequirements((current) => ({ ...current, [key]: value }))
  const filteredResults = hasSearched ? results : []

  return (
    <div className="space-y-5">
      <div className="rounded-2xl border bg-card p-5 sm:p-6">
        <div className="mb-5">
          <h3 className="text-base font-semibold">Tell us what you want to research</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Set filters for the demo companies. Only fields available in the current dataset can affect matching.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Market">
            <select value={requirements.market} onChange={(e) => { const next = e.target.value as ResearchRequirements['market']; setRequirements((current) => ({ ...current, market: next, maxSharePrice: next === 'All' ? '' : current.maxSharePrice })) }} className={fieldClass}>
              <option value="India">India</option>
              <option value="US">United States</option>
              <option value="All">All available markets</option>
            </select>
          </Field>
          <Field label="Exchange">
            <select value={requirements.exchange} onChange={(e) => update('exchange', e.target.value as ResearchRequirements['exchange'])} className={fieldClass}>
              <option value="Any">Any supported exchange</option>
              <option value="NSE">NSE · India</option>
              <option value="BSE">BSE · India</option>
              <option value="NYSE">NYSE · US</option>
              <option value="NASDAQ">NASDAQ · US</option>
            </select>
          </Field>
          <Field label="Sector">
            <select value={requirements.sector} onChange={(e) => update('sector', e.target.value)} className={fieldClass}>
              <option value="Any">Any sector</option>
              {SECTORS.map((sector) => <option key={sector} value={sector}>{sector}</option>)}
            </select>
          </Field>
          <Field label="Company size">
            <select value={requirements.capSize} onChange={(e) => update('capSize', e.target.value as ResearchRequirements['capSize'])} className={fieldClass}>
              <option value="Any">Any size</option>
              <option value="Large Cap">Large cap</option>
              <option value="Mid Cap">Mid cap</option>
              <option value="Small Cap">Small cap</option>
            </select>
          </Field>
          <Field label={`Maximum share price${requirements.market === 'US' ? ' (USD)' : requirements.market === 'India' ? ' (INR)' : ''}`}>
            <input
              type="number"
              min="0"
              step="any"
              inputMode="decimal"
              placeholder={requirements.market === 'US' ? 'e.g. 250' : 'e.g. 2000'}
              value={requirements.maxSharePrice}
              disabled={requirements.market === 'All'}
              onChange={(e) => update('maxSharePrice', e.target.value)}
              className={fieldClass}
            />
            <p className="mt-1 text-xs text-muted-foreground">
              Per-share research filter, not a suggested investment amount. Select one market to use it.
            </p>
          </Field>
          <Field label="Minimum revenue growth (%)">
            <input type="number" step="any" placeholder="e.g. 5" value={requirements.minRevenueGrowth} onChange={(e) => update('minRevenueGrowth', e.target.value)} className={fieldClass} />
          </Field>
          <Field label="Maximum debt-to-equity">
            <input type="number" min="0" step="any" placeholder="e.g. 1" value={requirements.maxDebtToEquity} onChange={(e) => update('maxDebtToEquity', e.target.value)} className={fieldClass} />
          </Field>
          <Field label="Maximum P/E ratio">
            <input type="number" min="0" step="any" placeholder="e.g. 30" value={requirements.maxPe} onChange={(e) => update('maxPe', e.target.value)} className={fieldClass} />
          </Field>
          <Field label="Research horizon">
            <select value={requirements.horizon} onChange={(e) => update('horizon', e.target.value as ResearchRequirements['horizon'])} className={fieldClass}>
              <option value="Any">No preference</option>
              <option value="Short term">Short term</option>
              <option value="Medium term">Medium term</option>
              <option value="Long term">Long term</option>
            </select>
            <p className="mt-1 text-xs text-muted-foreground">Recorded as context only; the demo data cannot assess time horizon.</p>
          </Field>
          <Field label="Additional research notes">
            <textarea
              rows={2}
              value={requirements.notes}
              onChange={(e) => update('notes', e.target.value)}
              placeholder="What else would you like to investigate?"
              className={`${fieldClass} min-h-20 resize-y`}
            />
            <p className="mt-1 text-xs text-muted-foreground">Notes are not interpreted or used to filter companies.</p>
          </Field>
        </div>

        <div className="mt-5 flex flex-wrap gap-x-6 gap-y-3">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={requirements.profitableOnly} onChange={(e) => update('profitableOnly', e.target.checked)} className="size-4 accent-primary" />
            Positive net income
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={requirements.positiveCashFlow} onChange={(e) => update('positiveCashFlow', e.target.checked)} className="size-4 accent-primary" />
            Positive operating cash flow
          </label>
          <Field label="Risk preference">
            <select value={requirements.risk} onChange={(e) => update('risk', e.target.value as Risk)} className={fieldClass}>
              <option value="Lower">Lower historical indicators</option>
              <option value="Balanced">Balanced indicators</option>
              <option value="Higher">Include higher-volatility profiles</option>
            </select>
          </Field>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          <Button onClick={onSearch}><Search /> Find matching companies</Button>
          <Button variant="outline" onClick={() => {
            setRequirements({
              market: 'India', exchange: 'Any', sector: 'Any', capSize: 'Any', risk: 'Balanced',
              maxSharePrice: '', minRevenueGrowth: '', profitableOnly: false,
              maxDebtToEquity: '', positiveCashFlow: false, maxPe: '',
              horizon: 'Any', notes: '',
            })
            onSearch()
          }}>
            Reset filters
          </Button>
        </div>
        <p className="mt-4 text-xs text-muted-foreground">
          Dividend information is not present in this demo dataset, so it cannot be filtered. Share price is a per-share limit, not a total budget.
        </p>
      </div>

      {hasSearched && (
        <section aria-live="polite" className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="font-semibold">Research matches</h3>
              <p className="text-sm text-muted-foreground">{filteredResults.length} of {listStocks().length} companies match the selected data filters.</p>
            </div>
            <DemoBadge />
          </div>
          {(requirements.horizon !== 'Any' || requirements.notes.trim()) && (
            <div className="rounded-xl border bg-card px-4 py-3 text-sm">
              <p className="font-medium">Additional research context (not used as a filter)</p>
              {requirements.horizon !== 'Any' && <p className="mt-1 text-muted-foreground">Horizon: {requirements.horizon}</p>}
              {requirements.notes.trim() && <p className="mt-1 text-muted-foreground">Notes: {requirements.notes}</p>}
            </div>
          )}
          {filteredResults.length === 0 ? (
            <div className="rounded-2xl border border-dashed bg-card p-8 text-center">
              <p className="font-semibold">No companies match all these filters</p>
              <p className="mt-1 text-sm text-muted-foreground">Try relaxing one or more filters. Stockzz will not invent matches when the available dataset has none.</p>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {filteredResults.map((stock) => (
                <RequirementResultCard key={stock.profile.symbol} stock={stock} requirements={requirements} />
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  )
}

const fieldClass = 'mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50'

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block min-w-0 text-sm font-medium">{label}{children}</label>
}

function RequirementResultCard({ stock, requirements }: { stock: StockRecord; requirements: ResearchRequirements }) {
  const { profile, quote, fundamentals } = stock
  const { isSaved, toggleSaved } = useWorkspace()
  const saved = isSaved(profile.symbol)
  const labels = matchedRequirementLabels(stock, requirements)
  return (
    <article className="flex flex-col rounded-2xl border bg-card p-5">
      <div className="flex items-start gap-3">
        <CompanyMark profile={profile} />
        <div className="min-w-0 flex-1">
          <h4 className="font-semibold">{profile.name}</h4>
          <p className="text-xs text-muted-foreground">{profile.symbol} · {profile.exchange} · {profile.sector}</p>
        </div>
        <button
          type="button"
          onClick={() => toggleSaved(profile.symbol)}
          aria-label={saved ? `Remove ${profile.name} from saved` : `Save ${profile.name}`}
          aria-pressed={saved}
          className="rounded-md p-1.5 hover:bg-muted"
        >
          <Star className={cn('size-4', saved ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground')} />
        </button>
      </div>
      <div className="mt-3 flex items-center justify-between gap-2">
        <span className="rounded-md bg-accent px-2 py-0.5 text-xs font-medium text-accent-foreground">{profile.capSize}</span>
        <DemoBadge />
      </div>
      <p className="mt-3 text-lg font-semibold tabular-nums">{money(quote.price, profile.currency)} <span className="text-xs font-normal text-muted-foreground">per share (sample)</span></p>
      <div className="mt-3 grid grid-cols-2 gap-3 text-xs">
        <Metric label="Revenue growth" value={`${fundamentals.revenueGrowthPct.toFixed(1)}%`} />
        <Metric label="Net income" value={fundamentals.netIncome > 0 ? 'Positive' : 'Not positive'} />
        <Metric label="Debt / equity" value={fundamentals.debtToEquity.toFixed(2)} />
        <Metric label="P/E ratio" value={fundamentals.pe.toFixed(1)} />
        <Metric label="Operating cash flow" value={fundamentals.operatingCashFlow > 0 ? 'Positive' : 'Not positive'} />
        <Metric label="Profit margin" value={`${fundamentals.profitMarginPct.toFixed(1)}%`} />
      </div>
      <div className="mt-4">
        <p className="mb-2 text-xs font-semibold">Matched criteria</p>
        <ul className="flex flex-wrap gap-1.5">
          {labels.map((label) => <li key={label} className="rounded-md bg-muted px-2 py-1 text-xs text-muted-foreground">{label}</li>)}
        </ul>
      </div>
      <SourceLine meta={quote.meta} className="mt-4" />
      <Button asChild className="mt-4 w-full">
        <Link to="/stock/$symbol" params={{ symbol: profile.symbol }}>Open full analysis <ArrowRight /></Link>
      </Button>
    </article>
  )
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded-lg bg-muted/60 p-2"><p className="text-muted-foreground">{label}</p><p className="mt-0.5 font-semibold">{value}</p></div>
}

function StatCard({ label, demo, children }: { label: string; demo?: boolean; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border bg-card p-5">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{label}</p>
        {demo && <DemoBadge />}
      </div>
      {children}
    </div>
  )
}

function PrefGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <fieldset>
      <legend className="mb-2 text-sm font-medium">{label}</legend>
      <div className="flex flex-wrap gap-2">{children}</div>
    </fieldset>
  )
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        'rounded-full border px-3 py-1 text-sm transition-colors',
        active ? 'border-primary bg-primary text-primary-foreground' : 'bg-background hover:bg-muted',
      )}
    >
      {children}
    </button>
  )
}

function SuggestionCard({ stock }: { stock: StockRecord }) {
  const { profile, quote, suggestion } = stock
  const { isSaved, toggleSaved } = useWorkspace()
  const saved = isSaved(profile.symbol)
  return (
    <article className="flex flex-col rounded-2xl border bg-card p-5">
      <div className="flex items-start gap-3">
        <CompanyMark profile={profile} />
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-semibold">{profile.name}</h3>
          <p className="text-xs text-muted-foreground">{profile.symbol} · {profile.exchange}</p>
        </div>
        <button
          type="button"
          onClick={() => toggleSaved(profile.symbol)}
          aria-label={saved ? `Remove ${profile.name} from saved` : `Save ${profile.name}`}
          aria-pressed={saved}
          className="rounded-md p-1.5 hover:bg-muted"
        >
          <Star className={cn('size-4', saved ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground')} />
        </button>
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        <span className="rounded-md bg-accent px-2 py-0.5 text-xs font-medium text-accent-foreground">{profile.sector}</span>
        <span className="rounded-md bg-muted px-2 py-0.5 text-xs text-muted-foreground">{profile.capSize}</span>
        <DemoBadge className="ml-auto" />
      </div>

      <p className="mt-3 text-sm leading-relaxed">
        <span className="font-medium">Why it’s here: </span>
        {suggestion.why}
      </p>

      <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
        <div>
          <p className="mb-1.5 font-semibold">Key strengths</p>
          <ul className="space-y-1">
            {suggestion.strengths.map((x) => (
              <li key={x} className="flex gap-1.5"><CircleCheck className="mt-px size-3.5 shrink-0 text-positive" aria-hidden />{x}</li>
            ))}
          </ul>
        </div>
        <div>
          <p className="mb-1.5 font-semibold">Key risks</p>
          <ul className="space-y-1">
            {suggestion.risks.map((x) => (
              <li key={x} className="flex gap-1.5"><CircleAlert className="mt-px size-3.5 shrink-0 text-negative" aria-hidden />{x}</li>
            ))}
          </ul>
        </div>
      </div>

      <p className="mt-4 flex gap-1.5 rounded-lg bg-muted px-3 py-2 text-xs text-muted-foreground">
        <Megaphone className="size-3.5 shrink-0" aria-hidden /> {suggestion.developments}
      </p>

      <div className="mt-4 flex items-center justify-between text-sm">
        <span className="font-semibold tabular-nums">{money(quote.price, profile.currency)}</span>
        <Change value={quote.change} pct={quote.changePct} className="text-xs" />
      </div>

      <Button asChild className="mt-4 w-full">
        <Link to="/stock/$symbol" params={{ symbol: profile.symbol }}>
          View analysis <ArrowRight />
        </Link>
      </Button>
    </article>
  )
}

